<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'admindcn');

/** MySQL database password */
define('DB_PASSWORD', 'opI!xkfUslLs@Hjef)G7pVFe');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/** Set by Ludwig at initialisiation accoring to this tutorial: https://www.digitalocean.com/community/tutorials/how-to-install-wordpress-with-lemp-on-ubuntu-16-04 */
define('FS_METHOD', 'direct');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'DLy(-0di7NemrV0ep^v3Z%J0CE^ u`nQ3+J9L:j~ |&R>kGBxLsoDv37R.|=`M*W');
define('SECURE_AUTH_KEY',  '3/``EG2 :!)Q7#V$>d_DaG*(;5yolM79=nAM%b_46!Y=YVgxpwawT>x%jn |)h5F');
define('LOGGED_IN_KEY',    '%g*xz~-YVT]`-sicK1EU]%s3b65 ^]68h@F]Aln)At~B[1u[X4FB>~Z2LO>{35.g');
define('NONCE_KEY',        'UWf$kwZl-l%{Z#aidbxi(d]|.-XnJ`.p=ALXO0%Es^vko5e{/R]#q[18!]8C}[(P');
define('AUTH_SALT',        'el)&j+]I:SM9+ghA*MG.@u3B(u0D}6*+ZFC%-Ih8Of<6tX+w{sQD{o;0Wg1gdoSP');
define('SECURE_AUTH_SALT', 'hdt{U, zi@GhNcb+Ff#eW6>5e5|.e-Knmvk$+~^<V4;gtz$KqZ#_N~%L{Hw|%^}0');
define('LOGGED_IN_SALT',   '`+[5j}/RnjLl>tQM6,/hJ+# +^jbaHy|l*Jq(&Fc.xJ(`|L`cg7@H6f~ZS?pm)|c');
define('NONCE_SALT',       'm0ef,GADY=#;_@qYb|h hFa.P*G>*feqb!b4$c!$#tyr%(/+UQ!%BmsSQC:9p&|v');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'community_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
